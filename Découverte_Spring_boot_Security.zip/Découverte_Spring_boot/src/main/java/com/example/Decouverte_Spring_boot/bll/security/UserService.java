package com.example.Decouverte_Spring_boot.bll.security;

import org.springframework.security.core.userdetails.UserDetailsService;

public interface UserService extends UserDetailsService {
}
