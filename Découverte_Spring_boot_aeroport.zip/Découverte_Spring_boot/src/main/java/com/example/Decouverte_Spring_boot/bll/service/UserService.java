package com.example.Decouverte_Spring_boot.bll.service;

public interface UserService {
}
