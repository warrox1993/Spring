package com.example.Decouverte_Spring_boot.dal.entities.fiscals;

import jakarta.persistence.Entity;
import lombok.Data;

@Entity(name = "Mechanic")
@Data
public class MechanicEntity extends FiscalEntity {

}
