## Dal (Data access layer)

Couche contenant nos repositories, ceux-ci nous permettent de spécifier des méthodes afin d'accéder
aux données en db.