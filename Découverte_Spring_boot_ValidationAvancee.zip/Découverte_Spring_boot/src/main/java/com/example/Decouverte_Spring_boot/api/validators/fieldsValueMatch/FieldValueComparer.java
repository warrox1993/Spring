package com.example.Decouverte_Spring_boot.api.validators.fieldsValueMatch;

public enum FieldValueComparer {
    EQUALS, NOT_EQUALS,
    GT, GTE, LT, LTE
}
