package com.example.Decouverte_Spring_boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DecouverteSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
