package be.bstorm.graphql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tf2025SpringGraphqlApplication {

    public static void main(String[] args) {
        SpringApplication.run(Tf2025SpringGraphqlApplication.class, args);
    }

}
