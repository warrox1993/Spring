package be.bstorm.graphql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tf2025SpringGraphqlApplicationTests {

    @Test
    void contextLoads() {
    }

}
