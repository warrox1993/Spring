package be.bstorm.java.freemarker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FreemarkerApplicationTests {

    @Test
    void contextLoads() {
    }

}
